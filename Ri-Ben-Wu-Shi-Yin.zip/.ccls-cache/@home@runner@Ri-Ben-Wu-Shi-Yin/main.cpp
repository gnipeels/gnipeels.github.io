#include <iostream>
#include<cstdlib>
#include<ctime>
using namespace std;

int main() {
  srand( time(NULL) );
  int score=0;
  string 平假名[5] = {"あ","い","う","え","お"};
  string 拼音[5] = {"a","i","u","e","o"};
  int 番号;
  string answer;
  for(int i = 0; i < 10; i++){
    番号 = rand() % 5;
    cout << 平假名[番号];
    cin >> answer;
    if(answer == 拼音[番号]){
      cout << "正解！\n";
      score++;
    }else{
      cout << "不正解！\n答えは" << 拼音[番号] << "\n";
    };
  }
  cout << "あなたのスコアは" << score << "です。\n";
}